const express = require('express');
const multer = require('multer');
const path = require('path');
const pool = require('../db');
const { adminAuth } = require('../middleware/auth');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// Get all products (with optional search)
router.get('/', async (req, res) => {
  const { search, category } = req.query;
  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];
  if (search) { params.push(`%${search}%`); query += ` AND (name ILIKE $${params.length} OR description ILIKE $${params.length})`; }
  if (category) { params.push(category); query += ` AND category=$${params.length}`; }
  query += ' ORDER BY created_at DESC';
  const result = await pool.query(query, params);
  res.json(result.rows);
});

// Get single product
router.get('/:id', async (req, res) => {
  const result = await pool.query('SELECT * FROM products WHERE id=$1', [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: 'Not found' });
  res.json(result.rows[0]);
});

// Add product (admin)
router.post('/', adminAuth, upload.single('image'), async (req, res) => {
  const { name, description, price, category, stock } = req.body;
  const image_url = req.file ? `/uploads/${req.file.filename}` : null;
  const result = await pool.query(
    'INSERT INTO products (name, description, price, category, image_url, stock) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
    [name, description, price, category, image_url, stock || 0]
  );
  res.json(result.rows[0]);
});

// Update product (admin)
router.put('/:id', adminAuth, upload.single('image'), async (req, res) => {
  const { name, description, price, category, stock } = req.body;
  const image_url = req.file ? `/uploads/${req.file.filename}` : req.body.image_url;
  const result = await pool.query(
    'UPDATE products SET name=$1, description=$2, price=$3, category=$4, image_url=$5, stock=$6 WHERE id=$7 RETURNING *',
    [name, description, price, category, image_url, stock, req.params.id]
  );
  res.json(result.rows[0]);
});

// Delete product (admin)
router.delete('/:id', adminAuth, async (req, res) => {
  await pool.query('DELETE FROM products WHERE id=$1', [req.params.id]);
  res.json({ message: 'Deleted' });
});

module.exports = router;
