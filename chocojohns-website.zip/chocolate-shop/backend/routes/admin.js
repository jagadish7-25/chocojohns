const express = require('express');
const pool = require('../db');
const { adminAuth } = require('../middleware/auth');
const router = express.Router();

// Get all users
router.get('/users', adminAuth, async (req, res) => {
  const result = await pool.query('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC');
  res.json(result.rows);
});

// Get all contact messages
router.get('/messages', adminAuth, async (req, res) => {
  const result = await pool.query('SELECT * FROM contact_messages ORDER BY created_at DESC');
  res.json(result.rows);
});

// Get dashboard stats
router.get('/stats', adminAuth, async (req, res) => {
  const users = await pool.query('SELECT COUNT(*) FROM users');
  const products = await pool.query('SELECT COUNT(*) FROM products');
  const messages = await pool.query('SELECT COUNT(*) FROM contact_messages');
  res.json({
    users: users.rows[0].count,
    products: products.rows[0].count,
    messages: messages.rows[0].count
  });
});

module.exports = router;
