# 🌳 CHOCOJOHNS - Complete Deployment Guide
## "make memories of life"

---

## 📁 Project Structure
```
chocolate-shop/
├── frontend/          ← React website
│   ├── src/
│   ├── Dockerfile
│   └── nginx.conf
├── backend/           ← Node.js API
│   ├── routes/
│   ├── Dockerfile
│   └── init.sql       ← Database tables + sample data
├── k8s/               ← Kubernetes files
│   ├── 00-namespace-config.yaml
│   ├── 01-postgres.yaml
│   ├── 02-backend.yaml
│   ├── 03-frontend.yaml
│   └── 04-ingress-alb.yaml
└── docker-compose.yml ← For local testing
```

---

## 🖥️ STEP 1 — Test Locally with Docker Compose

```bash
# Clone / copy project folder
cd chocolate-shop

# Start everything (database + backend + frontend)
docker-compose up --build

# Website runs at: http://localhost
# Backend API at:  http://localhost:5000
```

**Admin Login:**
- Email: `admin@chocolateshop.com`
- Password: `admin123`

---

## 🐳 STEP 2 — Build & Push Docker Images

```bash
# Login to Docker Hub
docker login

# Build backend image
docker build -t YOUR_USERNAME/chocojohns-backend:latest ./backend
docker push YOUR_USERNAME/chocojohns-backend:latest

# Build frontend image (with your real API domain)
docker build \
  --build-arg REACT_APP_API_URL=https://www.chocojohns.com \
  -t YOUR_USERNAME/chocojohns-frontend:latest \
  ./frontend
docker push YOUR_USERNAME/chocojohns-frontend:latest
```

> ⚠️ Replace `YOUR_USERNAME` with your Docker Hub username in:
> - `k8s/02-backend.yaml`
> - `k8s/03-frontend.yaml`

---

## ☸️ STEP 3 — Deploy to Kubernetes (AWS EKS)

### 3a. Create EKS Cluster
```bash
eksctl create cluster \
  --name chocojohns \
  --region us-east-1 \
  --nodegroup-name workers \
  --node-type t3.medium \
  --nodes 2 \
  --nodes-min 2 \
  --nodes-max 4
```

### 3b. Install AWS Load Balancer Controller
```bash
# Install cert-manager
kubectl apply --validate=false -f \
  https://github.com/jetstack/cert-manager/releases/latest/download/cert-manager.yaml

# Install AWS LB Controller (follow AWS docs for IAM policy)
helm repo add eks https://aws.github.io/eks-charts
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=chocojohns \
  --set serviceAccount.create=true
```

### 3c. Apply Kubernetes Configs
```bash
kubectl apply -f k8s/00-namespace-config.yaml
kubectl apply -f k8s/01-postgres.yaml
kubectl apply -f k8s/02-backend.yaml
kubectl apply -f k8s/03-frontend.yaml
kubectl apply -f k8s/04-ingress-alb.yaml
```

### 3d. Check everything is running
```bash
kubectl get pods -n chocojohns
kubectl get services -n chocojohns
kubectl get ingress -n chocojohns
```

---

## 🌐 STEP 4 — Set Up Route53 + Domain

### 4a. Get your ALB DNS name
```bash
kubectl get ingress chocojohns-ingress -n chocojohns
# Copy the ADDRESS column — it will look like:
# k8s-chocojohns-xxxxx.us-east-1.elb.amazonaws.com
```

### 4b. In AWS Route53 Console:
1. Go to **Route53 → Hosted Zones**
2. Create or select your hosted zone for `chocojohns.com`
3. Create **Record Set:**
   - Name: `www`
   - Type: `A`
   - Alias: ✅ Yes
   - Alias Target: *paste your ALB DNS name*
4. Create another record for apex domain:
   - Name: (blank / @)
   - Type: `A`
   - Alias: ✅ Yes
   - Alias Target: *same ALB DNS name*

### 4c. Get SSL Certificate (HTTPS)
1. Go to **AWS Certificate Manager (ACM)**
2. Request certificate for `chocojohns.com` and `*.chocojohns.com`
3. Validate via DNS (Route53 can do this automatically)
4. Copy the Certificate ARN
5. Paste it in `k8s/04-ingress-alb.yaml` where it says `YOUR-CERT-ID`
6. Re-apply: `kubectl apply -f k8s/04-ingress-alb.yaml`

---

## 🔧 Useful Commands

```bash
# View logs
kubectl logs -f deployment/backend -n chocojohns
kubectl logs -f deployment/frontend -n chocojohns

# Scale backend manually
kubectl scale deployment backend --replicas=3 -n chocojohns

# Update to new image version
kubectl set image deployment/backend backend=YOUR_USERNAME/chocojohns-backend:v2 -n chocojohns

# Restart deployment
kubectl rollout restart deployment/backend -n chocojohns

# Delete everything
kubectl delete namespace chocojohns
```

---

## 🔑 Default Credentials
| Service  | Value                             |
|----------|-----------------------------------|
| Admin Email | admin@chocolateshop.com        |
| Admin Password | admin123                    |
| DB Name  | chocolateshop                     |
| DB User  | postgres                          |
| DB Pass  | postgres123 *(change in prod!)*   |

---

## ✅ Features
- 🍫 Product catalog with images, search & categories
- 👤 User signup / login (JWT auth)
- 🔐 Admin panel (add/delete products, view users & messages)
- 📸 Product image upload
- 📬 Contact form
- 📱 Fully responsive mobile design
- 🐳 Dockerized (3 containers)
- ☸️ Kubernetes ready with HPA auto-scaling
- 🌐 AWS ALB + Route53 ready
