import React, { useState } from 'react';
import axios from 'axios';
import './Contact.css';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setSuccess(''); setError('');
    try {
      await axios.post(`${API}/api/contact`, form);
      setSuccess('Your message has been sent! We\'ll be in touch soon. 🍫');
      setForm({ name: '', email: '', message: '' });
    } catch {
      setError('Failed to send message. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="contact">
      <div className="contact-banner">
        <h1>Get In Touch</h1>
        <p>We'd love to hear from you</p>
      </div>

      <div className="contact-container">
        <div className="contact-info">
          <h2>Let's Talk Chocolate</h2>
          <p>Whether you have a question about our products, need help with an order, or want to discuss a custom chocolate creation — we're here for you.</p>

          <div className="info-items">
            <div className="info-item">
              <span className="info-icon">📧</span>
              <div>
                <strong>Email</strong>
                <p>hello@chocojohns.com</p>
              </div>
            </div>
            <div className="info-item">
              <span className="info-icon">📞</span>
              <div>
                <strong>Phone</strong>
                <p>+1 (555) 123-4567</p>
              </div>
            </div>
            <div className="info-item">
              <span className="info-icon">📍</span>
              <div>
                <strong>Address</strong>
                <p>123 Chocolate Lane, Sweet City, SC 12345</p>
              </div>
            </div>
            <div className="info-item">
              <span className="info-icon">🕒</span>
              <div>
                <strong>Hours</strong>
                <p>Mon–Sat: 9am – 6pm</p>
              </div>
            </div>
          </div>
        </div>

        <div className="contact-form-box">
          <h2>Send a Message</h2>
          {success && <div className="alert-success">{success}</div>}
          {error && <div className="alert-error">{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Your Name</label>
              <input type="text" placeholder="Full name" value={form.name}
                onChange={e => setForm({...form, name: e.target.value})} required />
            </div>
            <div className="form-group">
              <label>Email Address</label>
              <input type="email" placeholder="your@email.com" value={form.email}
                onChange={e => setForm({...form, email: e.target.value})} required />
            </div>
            <div className="form-group">
              <label>Message</label>
              <textarea rows="5" placeholder="Tell us how we can help..."
                value={form.message} onChange={e => setForm({...form, message: e.target.value})} required />
            </div>
            <button type="submit" className="btn-primary" style={{width:'100%'}} disabled={loading}>
              {loading ? 'Sending...' : 'Send Message 🍫'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
