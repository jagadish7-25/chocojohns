import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Shop.css';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export default function Shop() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${API}/api/products`, { params: { search, category } });
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  useEffect(() => { fetchProducts(); }, [search, category]);

  return (
    <div className="shop">
      <div className="shop-banner">
        <h1>Our Chocolate Collection</h1>
        <p>Handcrafted with love — find your perfect treat</p>
      </div>

      <div className="container">
        <div className="shop-filters">
          <input
            type="text"
            placeholder="🔍  Search chocolates..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="search-input"
          />
          <select value={category} onChange={e => setCategory(e.target.value)}>
            <option value="">All Categories</option>
            <option value="bars">Chocolate Bars</option>
            <option value="truffles">Truffles</option>
            <option value="pralines">Pralines</option>
            <option value="bark">Bark</option>
            <option value="gifts">Gift Boxes</option>
          </select>
        </div>

        {loading ? (
          <div className="loading">Loading delicious chocolates... 🍫</div>
        ) : products.length === 0 ? (
          <div className="no-products">No products found. Try a different search!</div>
        ) : (
          <div className="products-grid">
            {products.map(p => (
              <div key={p.id} className="product-card">
                <div className="product-img">
                  {p.image_url
                    ? <img src={`${API}${p.image_url}`} alt={p.name} />
                    : <div className="product-placeholder">🍫</div>
                  }
                  {p.stock > 0
                    ? <span className="badge-instock">In Stock</span>
                    : <span className="badge-outstock">Out of Stock</span>
                  }
                </div>
                <div className="product-info">
                  <span className="product-category">{p.category}</span>
                  <h3 className="product-name">{p.name}</h3>
                  <p className="product-desc">{p.description}</p>
                  <div className="product-footer">
                    <span className="product-price">${parseFloat(p.price).toFixed(2)}</span>
                    <button className="btn-primary" disabled={p.stock === 0}>
                      {p.stock > 0 ? 'Add to Cart' : 'Sold Out'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
