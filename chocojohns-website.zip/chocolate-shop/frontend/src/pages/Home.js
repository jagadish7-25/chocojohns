import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

export default function Home() {
  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero-content">
          <p className="hero-since">SINCE 2026</p>
          <h1 className="hero-title">CHOCOJOHNS</h1>
          <p className="hero-tagline">make memories of life</p>
          <p className="hero-desc">
            Handcrafted premium chocolates made with love and the finest ingredients.
            Every bite tells a story, every piece creates a memory.
          </p>
          <div className="hero-btns">
            <Link to="/shop" className="btn-primary">Shop Now</Link>
            <Link to="/contact" className="btn-outline">Contact Us</Link>
          </div>
        </div>
        <div className="hero-image">
          <div className="hero-circle">
            <span className="hero-emoji">🍫</span>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features">
        <div className="container">
          <p className="section-subtitle">Why Choose Us</p>
          <h2 className="section-title">The CHOCOJOHNS Difference</h2>
          <div className="features-grid">
            {[
              { icon: '🌿', title: 'All Natural', desc: 'Made with 100% natural ingredients, no artificial preservatives.' },
              { icon: '🎁', title: 'Perfect Gifts', desc: 'Beautiful packaging for every occasion, birthdays to weddings.' },
              { icon: '✋', title: 'Handcrafted', desc: 'Each chocolate is carefully crafted by our expert chocolatiers.' },
              { icon: '🚚', title: 'Fast Delivery', desc: 'Fresh chocolates delivered to your door within 2-3 days.' },
            ].map((f, i) => (
              <div key={i} className="feature-card">
                <div className="feature-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="categories">
        <div className="container">
          <p className="section-subtitle">Explore</p>
          <h2 className="section-title">Our Collections</h2>
          <div className="cat-grid">
            {[
              { emoji: '🍫', name: 'Chocolate Bars', desc: 'Dark, Milk & White' },
              { emoji: '🍬', name: 'Truffles', desc: 'Creamy & Indulgent' },
              { emoji: '🎁', name: 'Gift Boxes', desc: 'Perfect for Gifting' },
              { emoji: '🌰', name: 'Pralines', desc: 'Nutty & Delicious' },
            ].map((c, i) => (
              <Link key={i} to="/shop" className="cat-card">
                <div className="cat-emoji">{c.emoji}</div>
                <h3>{c.name}</h3>
                <p>{c.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="cta-banner">
        <div className="container">
          <h2>Create Sweet Memories Today</h2>
          <p>Join thousands of happy customers who trust CHOCOJOHNS for life's sweetest moments.</p>
          <div className="cta-btns">
            <Link to="/shop" className="btn-primary">Browse Shop</Link>
            <Link to="/register" className="btn-outline-white">Create Account</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
