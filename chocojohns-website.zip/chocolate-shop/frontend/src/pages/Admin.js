import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import './Admin.css';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export default function Admin() {
  const { user, token } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('dashboard');
  const [stats, setStats] = useState({});
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [form, setForm] = useState({ name: '', description: '', price: '', category: '', stock: '' });
  const [image, setImage] = useState(null);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (!user || user.role !== 'admin') { navigate('/login'); return; }
    fetchAll();
  }, [user]);

  const headers = { Authorization: `Bearer ${token}` };

  const fetchAll = async () => {
    const [s, p, u, m] = await Promise.all([
      axios.get(`${API}/api/admin/stats`, { headers }),
      axios.get(`${API}/api/products`),
      axios.get(`${API}/api/admin/users`, { headers }),
      axios.get(`${API}/api/admin/messages`, { headers }),
    ]);
    setStats(s.data); setProducts(p.data); setUsers(u.data); setMessages(m.data);
  };

  const addProduct = async (e) => {
    e.preventDefault();
    const data = new FormData();
    Object.entries(form).forEach(([k, v]) => data.append(k, v));
    if (image) data.append('image', image);
    try {
      await axios.post(`${API}/api/products`, data, { headers });
      setMsg('Product added successfully!');
      setForm({ name: '', description: '', price: '', category: '', stock: '' });
      setImage(null);
      fetchAll();
    } catch { setMsg('Error adding product'); }
  };

  const deleteProduct = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    await axios.delete(`${API}/api/products/${id}`, { headers });
    fetchAll();
  };

  return (
    <div className="admin">
      <div className="admin-sidebar">
        <div className="admin-brand">🌳 Admin Panel</div>
        {['dashboard', 'products', 'add-product', 'users', 'messages'].map(t => (
          <button key={t} className={`sidebar-btn ${tab === t ? 'active' : ''}`}
            onClick={() => setTab(t)}>
            {t === 'dashboard' && '📊 '}{t === 'products' && '🍫 '}{t === 'add-product' && '➕ '}{t === 'users' && '👥 '}{t === 'messages' && '✉️ '}
            {t.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase())}
          </button>
        ))}
      </div>

      <div className="admin-content">

        {tab === 'dashboard' && (
          <div>
            <h1 className="admin-title">Dashboard</h1>
            <div className="stats-grid">
              <div className="stat-card"><div className="stat-num">{stats.products}</div><div className="stat-label">Products</div></div>
              <div className="stat-card"><div className="stat-num">{stats.users}</div><div className="stat-label">Users</div></div>
              <div className="stat-card"><div className="stat-num">{stats.messages}</div><div className="stat-label">Messages</div></div>
            </div>
          </div>
        )}

        {tab === 'products' && (
          <div>
            <h1 className="admin-title">All Products</h1>
            <table className="admin-table">
              <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Action</th></tr></thead>
              <tbody>
                {products.map(p => (
                  <tr key={p.id}>
                    <td>
                      {p.image_url ? <img src={`${API}${p.image_url}`} alt={p.name} className="table-img" /> : '🍫'}
                    </td>
                    <td>{p.name}</td>
                    <td><span className="tag">{p.category}</span></td>
                    <td>${parseFloat(p.price).toFixed(2)}</td>
                    <td>{p.stock}</td>
                    <td><button className="btn-delete" onClick={() => deleteProduct(p.id)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'add-product' && (
          <div>
            <h1 className="admin-title">Add New Product</h1>
            {msg && <div className="alert-success">{msg}</div>}
            <form className="admin-form" onSubmit={addProduct}>
              <div className="form-row">
                <div className="form-group"><label>Product Name</label>
                  <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required /></div>
                <div className="form-group"><label>Category</label>
                  <select value={form.category} onChange={e => setForm({...form, category: e.target.value})} required>
                    <option value="">Select category</option>
                    <option value="bars">Bars</option><option value="truffles">Truffles</option>
                    <option value="pralines">Pralines</option><option value="bark">Bark</option>
                    <option value="gifts">Gift Boxes</option>
                  </select></div>
              </div>
              <div className="form-group"><label>Description</label>
                <textarea rows="3" value={form.description} onChange={e => setForm({...form, description: e.target.value})} /></div>
              <div className="form-row">
                <div className="form-group"><label>Price ($)</label>
                  <input type="number" step="0.01" value={form.price} onChange={e => setForm({...form, price: e.target.value})} required /></div>
                <div className="form-group"><label>Stock</label>
                  <input type="number" value={form.stock} onChange={e => setForm({...form, stock: e.target.value})} required /></div>
              </div>
              <div className="form-group"><label>Product Image</label>
                <input type="file" accept="image/*" onChange={e => setImage(e.target.files[0])} /></div>
              <button type="submit" className="btn-primary">Add Product</button>
            </form>
          </div>
        )}

        {tab === 'users' && (
          <div>
            <h1 className="admin-title">All Users</h1>
            <table className="admin-table">
              <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id}>
                    <td>#{u.id}</td><td>{u.name}</td><td>{u.email}</td>
                    <td><span className={`tag ${u.role === 'admin' ? 'tag-admin' : ''}`}>{u.role}</span></td>
                    <td>{new Date(u.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'messages' && (
          <div>
            <h1 className="admin-title">Contact Messages</h1>
            <div className="messages-list">
              {messages.map(m => (
                <div key={m.id} className="message-card">
                  <div className="msg-header">
                    <strong>{m.name}</strong>
                    <span>{m.email}</span>
                    <span className="msg-date">{new Date(m.created_at).toLocaleDateString()}</span>
                  </div>
                  <p>{m.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
