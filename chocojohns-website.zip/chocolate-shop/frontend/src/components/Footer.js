import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-brand">
          <div className="footer-logo">🌳 CHOCOJOHNS</div>
          <p>make memories of life</p>
          <p className="footer-since">Since 2026</p>
        </div>
        <div className="footer-links">
          <h4>Quick Links</h4>
          <Link to="/">Home</Link>
          <Link to="/shop">Shop</Link>
          <Link to="/contact">Contact</Link>
        </div>
        <div className="footer-contact">
          <h4>Contact Us</h4>
          <p>📧 hello@chocojohns.com</p>
          <p>📞 +1 (555) 123-4567</p>
          <p>📍 123 Chocolate Lane, Sweet City</p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© 2026 CHOCOJOHNS. All rights reserved.</p>
      </div>
    </footer>
  );
}
